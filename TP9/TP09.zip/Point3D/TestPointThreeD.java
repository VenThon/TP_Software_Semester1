package TP9.Point3D;

public class TestPointThreeD {
    public static void main(String[] args) {
        PointThreeD p = PointThreeD.inputData();
        System.out.println(p);
    }
}
