// package TP11.src.exceptions;
public class DBException extends RuntimeException {
    public DBException(Throwable e){
        super(e);
    }
}
